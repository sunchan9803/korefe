import os

from django.conf import settings
from django.shortcuts import render
from django.views.generic import View


class IndexView(View):
    def get(self, request):
        json_file_url = os.path.join(settings.STATIC_URL, 'festival', 'data.json')
        return render(request, 'map/index.html', {'page': 'map', 'json_file_url': json_file_url})
