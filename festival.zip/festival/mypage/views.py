from datetime import datetime

from allauth.socialaccount.models import SocialAccount
from django.shortcuts import render
from django.views.generic import View


class IndexView(View):
    def get(self, request):
        user = self.request.user

        if user.is_authenticated:
            social_user = SocialAccount.objects.get(user_id=user.id)
            social_user = social_user.extra_data
            social_user['connected_at']  = datetime.strptime(social_user['connected_at'], "%Y-%m-%dT%H:%M:%SZ").date()

            return render(request, 'mypage/index.html', {'page': 'mypage', 'social':social_user})
        else:
            return render(request, 'mypage/login.html', {'page': 'mypage'})


class LoginView(View):
    def get(self, request):
        return render(request, 'mypage/login.html', {'page': 'mypage'})