from django.contrib.auth.models import User
from django.db import models

from festival_info.models import Festival


# Create your models here.
class UserLike(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    like_festival = models.ForeignKey(Festival, on_delete=models.CASCADE)

    class Meta:
        db_table = 'user_like'