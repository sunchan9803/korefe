from django.urls import path

from . import views

app_name = 'mypaqge'

urlpatterns = [
    path('', views.IndexView.as_view(), name='index_view'),
    path('login/', views.LoginView.as_view(), name='login_view'),
]