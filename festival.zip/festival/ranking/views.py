from django.shortcuts import render
from django.views.generic import View, ListView

from festival_info.models import Festival


# class IndexView(View):
#     def get(self, request):
#         return render(request, 'ranking/index.html', {'page': 'ranking'})

class RankingListView(ListView):
    model = Festival
    context_object_name = 'festival_list'
    template_name = 'ranking/index.html'
    paginate_by = 10

    def get_queryset(self):
        queryset = super().get_queryset()
        queryset = queryset.order_by('-view_count')

        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        festival_list = context['festival_list']

        for index, festival in enumerate(festival_list, start=1):
            festival.rank = index

        context['page'] = 'ranking'

        return context
