document.addEventListener('DOMContentLoaded', function () {
    let page = 1;
    let isLoading = false;

    // 스크롤 이벤트 핸들러
    window.addEventListener('scroll', async function () {
        if (window.scrollY + window.innerHeight >= document.documentElement.scrollHeight - 10) {
            if (!isLoading) {
                await loadMore();
            }
        }
    });

    // 추가 데이터 로드 함수
    async function loadMore() {
        page += 1;
        isLoading = true;

        const search_date = document.querySelector('[name=search_date]').value;
        const search_region = document.querySelector('[name=search_region]').value;

        try {
            const response = await fetch(`?page=${page}&search_date=${search_date}&search_region=${search_region}`, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',  // 헤더 추가
                },
            });
            if (!response.ok) throw new Error('Network response was not ok');

            const data = await response.text();  // HTML 데이터를 받아옴
            document.getElementById('festival-container').insertAdjacentHTML('beforeend', data);

        } catch (error) {
            console.error('Failed to load more data:', error);
        } finally {
            isLoading = false;
        }
    }

});

