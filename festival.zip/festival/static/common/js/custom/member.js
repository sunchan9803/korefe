const detailModifyBtn = document.querySelector('#modify-btn');
const detailSubmitBtn = document.querySelector('#submit-btn');
const detailSubmitContainer = document.querySelector('.submit-container');
const detailModifyContainer = document.querySelector('.modify-container');
const detailForm = document.querySelector('#member-detail');

detailModifyBtn.addEventListener('click', (e) => {
    detailForm.querySelectorAll('input, textarea, select').forEach((ele, i) => {
        if (ele.name === 'user_id') {
            return;
        }

        ele.disabled = false;
    });

    detailSubmitContainer.style.display = 'block';
    detailModifyContainer.style.display = 'none';
});

detailSubmitBtn.addEventListener('click', (e) => {
    e.preventDefault();

    if (!confirm('수정하시겠습니까?')) {
        return;
    }

    detailForm.submit();
})