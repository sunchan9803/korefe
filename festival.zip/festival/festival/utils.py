import json
import os

from django.conf import settings


def is_ajax(request):
    return request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'


def create_json_file(data):
    file_path = os.path.join(settings.STATICFILES_DIRS[0], 'festival', 'data.json')

    os.makedirs(os.path.dirname(file_path), exist_ok=True)

    # JSON 파일 생성
    with open(file_path, 'w', encoding='utf-8') as json_file:
        json.dump(data, json_file, ensure_ascii=False, indent=4)

    return file_path
