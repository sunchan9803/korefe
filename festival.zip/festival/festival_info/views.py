from datetime import datetime, date
from webbrowser import Error

from django.contrib.admin.templatetags.admin_list import pagination
from django.contrib.auth.decorators import login_required
from django.db.models import Case, When, Value, BooleanField
from django.http import JsonResponse
from django.utils.decorators import method_decorator
from django.views.generic import ListView, DetailView

from django.db import transaction, IntegrityError
from django.shortcuts import render, get_object_or_404
from django.views.generic import View
import requests
from sqlparse.sql import Where

from festival.utils import is_ajax, create_json_file
from festival_info.models import Festival
from mypage.models import UserLike


class RegionView(View):
    def get(self, request):
        return render(request, 'festival_info/index.html', {'page': 'region'})


class FestivalDetailView(DetailView):
    model = Festival
    template_name = 'festival_info/detail.html'
    context_object_name = 'festival'

    def get(self, request, *args, **kwargs):
        festival = self.get_object()

        festival.view_count += 1
        festival.save()

        return super().get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page'] = 'region'

        today = date.today()

        festival = context['festival']
        start = festival.start_date
        end = festival.end_date

        is_running = False
        if start <= today <= end:
            is_running = True

        context['running'] = is_running
        context['like'] = False
        context['login'] = 'N'

        if self.request.user.is_authenticated:
            context['login'] = 'Y'

            festival_id = self.kwargs.get('pk')
            like = UserLike.objects.filter(
                user=self.request.user,
                like_festival_id=festival_id
            ).exists()

            if like:
                context['like'] = True

        return context


class FestivalListView(ListView):
    model = Festival
    template_name = 'festival_info/index.html'
    context_object_name = 'festival_list'
    paginate_by = 9

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        today = date.today()

        festival_list = context['festival_list']

        for festival in festival_list:
            start = festival.start_date
            end = festival.end_date

            is_running = False
            if start <= today <= end:
                is_running = True

            festival.running = is_running

        context['page'] = 'region'

        context['search_date'] = self.request.GET.get('search_date', '')
        context['search_region'] = self.request.GET.get('search_region', '')
        return context

    def render_to_response(self, context, **response_kwargs):
        if is_ajax(self.request):
            return render(self.request, 'festival_info/list.html', context)
        return super().render_to_response(context, **response_kwargs)

    def get_queryset(self):
        queryset = super().get_queryset()

        search_month = self.request.GET.get('search_date')
        search_region = self.request.GET.get('search_region')
        mypage = self.request.GET.get('mypage')
        keyword = self.request.GET.get('keyword')

        if search_month:
            queryset = queryset.filter(
                start_date__month=search_month,
                end_date__month=search_month
            )

        if search_region:
            queryset = queryset.filter(
                addr__icontains=search_region
            )

        if mypage:
            user = self.request.user
            if user.is_authenticated:
                liked_festival_ids = UserLike.objects.filter(user=user).values_list('like_festival', flat=True)
                queryset = queryset.filter(id__in=liked_festival_ids)

        if keyword:
            queryset = queryset.filter(
                name__icontains=keyword
            )

        today = date.today()

        queryset = queryset.annotate(
            is_running=Case(
                When(start_date__lte=today, end_date__gte=today, then=Value(True)),
                default=Value(False),
                output_field=BooleanField(),
            )
        ).order_by('-is_running', 'start_date')

        return queryset

    def get_paginate_by(self, queryset):
        paginate_by = super().get_paginate_by(queryset)

        limit = self.request.GET.get('limit')

        if limit:
            paginate_by = limit

        return paginate_by


class LikeView(View):
    def get(self, request, *args, **kwargs):
        try:
            user = self.request.user

            if not user.is_authenticated:
                return JsonResponse({'success': False, 'message': 'USER_NOT_LOGGED_IN'})

            festival_id = kwargs.get('id')

            festival = Festival.objects.get(id=festival_id)

            user_like = UserLike.objects.filter(user=user, like_festival=festival).exists()

            if not user_like:
                UserLike.objects.create(user=user, like_festival=festival)
                festival.like_count += 1
                message = 'LIKED'
            else:
                UserLike.objects.filter(user=user, like_festival=festival).delete()
                festival.like_count -= 1
                message = 'UNLIKED'

            festival.save()
        except Festival.DoesNotExist:
            return JsonResponse({'success': False, 'message': 'FESTIVAL_NOT_FOUND'})

        return JsonResponse({'success': True, 'message': message})


@transaction.atomic
def fetch_upsert_festival():
    url = ('http://api.data.go.kr/openapi/tn_pubr_public_cltur_fstvl_api'
           '?serviceKey=Y4LiMdrwbMh3z%2FvQAkkuRh44eNUU4j4kuykW6h9mcKXHPM7ys9LnF4YuUXvTNpSl3KEsH8EJdVQs7skY3xCDrA%3D%3D'
           '&pageNo=1'
           '&numOfRows=1500'
           '&type=json')

    response = requests.get(url)

    if response.status_code == 200:
        # 요청 성공
        try:
            data = response.json()

            json_list = []

            for item in data['response']['body']['items']:
                name = item['fstvlNm']
                desc = item['fstvlCo']
                corp_name = item['mnnstNm']
                corp_tel = item['phoneNumber']
                corp_homepage = item['homepageUrl']
                addr = item['rdnmadr']
                start_date = item['fstvlStartDate']
                end_date = item['fstvlEndDate']
                latitude = item['latitude']
                longitude = item['longitude']

                json_list.append({
                    "title": name,
                    "lat": latitude,
                    "lng": longitude
                })

                try:
                    _, created = Festival.objects.get_or_create(
                        name=name,
                        defaults={
                            'desc': desc,
                            'corp_name': corp_name,
                            'corp_tel': corp_tel,
                            'corp_homepage': corp_homepage,
                            'addr': addr,
                            'start_date': start_date,
                            'end_date': end_date,
                            'latitude': latitude,
                            'longitude': longitude
                        }
                    )

                    create_json_file(json_list)

                except IntegrityError:
                    print(f"Duplicate '{name}'.")


        except ValueError:
            print("Failed to parse JSON")
    else:
        # 요청 실패
        print(f"Failed request with status code: {response.status_code}")
