from django.urls import path

from . import views

app_name = 'festival_info'

urlpatterns = [
    path('', views.FestivalListView.as_view(), name='region_view'),
    path('detail/<int:pk>/', views.FestivalDetailView.as_view(), name='region_detail_view'),
    path('like/<int:id>/', views.LikeView.as_view(), name='region_like_view'),
    path('test/', views.fetch_upsert_festival, name='region_like_view'),
]