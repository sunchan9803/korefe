from django.apps import AppConfig


class FestivalInfoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'festival_info'
