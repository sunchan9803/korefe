from django.db import models

# Create your models here.

class Festival(models.Model):
    name = models.CharField(max_length=100,unique=True, verbose_name='축제명')
    desc = models.CharField(max_length=255, verbose_name='축제설명')
    corp_name = models.CharField(max_length=50, verbose_name='주관기관명')
    corp_tel = models.CharField(max_length=13, verbose_name='안내번호')
    corp_homepage = models.CharField(max_length=255, blank=True, null=True, verbose_name='홈페이지')
    addr = models.CharField(max_length=100, verbose_name='주소')
    like_count = models.IntegerField(max_length=10, default=0, verbose_name='좋아요수')
    share_count = models.IntegerField(max_length=10, default=0, verbose_name='공유수')
    view_count = models.IntegerField(max_length=10, default=0, verbose_name='조회수')
    latitude = models.CharField(max_length=15, blank=True, null=True, verbose_name='위도')
    longitude = models.CharField(max_length=15, blank=True, null=True, verbose_name='경도')
    start_date = models.DateField(verbose_name='시작일자')
    end_date = models.DateField(verbose_name='종료일자')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'festival'